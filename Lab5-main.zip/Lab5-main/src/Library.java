import java.util.List;

public class Library {
    private String name;
    private String location;
    private List<Book> catalog;
    private List<Member> members;
    List<Librarian> librarians;
    public void registerLibrarian(Member member){
        
    }
}
