public class Book {
    private String bookID;
    private String title;
    private String author;
    private boolean isAvailable;
    public boolean borrowBook(){
        return true;
    }
    public boolean returnBook(){
        return true;
    }
    public void displayBook(){

    }
}
