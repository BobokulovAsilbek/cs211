import java.util.List;

public class Member {
    private String memberID;
    private String title;
    private List<Book> borrowedBooks;
    public void borrowBook(){

    }
    public void returnBook(){

    }
    public void viewBorrowedBooks(){

    }
}
