public class Main {
    public static void main(String[] args) {

        System.out.println("Welcome to NUU library");
        System.out.println("1. Login as ADMIN");
        System.out.println("2. Login as Librarian");
        System.out.println("3. Login as Member");
        System.out.println("4. Continue as Guest");
        System.out.println("0. Exit ");
        Library library = new Library();

    }
}