import java.util.List;

public class Librarian {
    private String librarianID;
    private String name;
    private List<Book> managedBooks;
    public void addBook(){

    }
    public void removeBook(){

    }
    public void issueBook(){

    }
}
