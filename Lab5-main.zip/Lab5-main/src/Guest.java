public class Guest {
    public void viewCatalog(){

    }
}
